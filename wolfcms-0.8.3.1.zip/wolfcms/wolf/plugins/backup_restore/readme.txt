== WHAT IT IS ==

The BackupRestore plugin provides administrators with the option of backing up
their pages, settings and uploaded files to an XML file.

== HOW TO USE IT ==

* Enable the plugin and read the documentation page by clicking on the plugin's
  name in the Wolf CMS administration area.

== NOTES ==

* To use the settings and documentation pages, you will first need to enable
  the plugin!

* This plugin is only useable by the user with user id '1'.

* Upgrade this plugin by uninstalling it and re-enabling it.
  You'll have to check your settings afterwards.

== LICENSE ==

Copyright 2009-2011, Martijn van der Kleijn. <martijn.niji@gmail.com>
This plugin is licensed under the GPLv3 License.
<http://www.gnu.org/licenses/gpl.html>