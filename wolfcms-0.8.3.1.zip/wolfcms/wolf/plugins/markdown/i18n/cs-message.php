<?php

/**
 * Wolf CMS markdown plugin language file
 *
 * @package Translations
 */

return array(
    'Allows you to use the Markdown text filter (with MarkdownExtra and Smartypants).' => 'Umožňuje Vám využívat textový filtr Markdown (spolu s MarkdownExtra a Smartypants).',
    'Markdown filter' => 'Markdown filtr',
    'Markdown' => 'Markdown'
);