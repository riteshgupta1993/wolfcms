<?php

/**
 * Wolf CMS markdown plugin language file
 *
 * @package Translations
 */

return array(
    'Allows you to use the Markdown text filter (with MarkdownExtra and Smartypants).' => 'Ermöglicht es Ihnen den Mardown-Textfilter zu verwenden. (inklusive MarkdownExtra und Smartypants)',
    'Markdown filter' => 'Markdown-Filter',
    'Markdown' => 'Markdown'
);