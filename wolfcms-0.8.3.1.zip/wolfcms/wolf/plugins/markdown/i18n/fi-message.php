<?php

/**
 * Wolf CMS markdown plugin language file
 *
 * @package Translations
 */

return array(
    'Allows you to use the Markdown text filter (with MarkdownExtra and Smartypants).' => 'Mahdollistaa Markdown-muotoilukielen käyttämisen (MarkdownExtran ja Smartypantsin kera).',
    'Markdown filter' => 'Markdown-suodin',
    'Markdown' => 'Markdown'
);