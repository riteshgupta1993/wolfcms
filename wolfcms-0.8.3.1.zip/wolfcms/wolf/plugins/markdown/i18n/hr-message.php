<?php

/**
 * Wolf CMS markdown plugin language file
 *
 * @package Translations
 */

return array(
    'Allows you to use the Markdown text filter (with MarkdownExtra and Smartypants).' => 'Omogućuje vam da koristite Markdown tekstualni filter (s MarkdownExtra i Smartypants).',
    'Markdown filter' => 'Markdown filter',
    'Markdown' => 'Markdown'
);