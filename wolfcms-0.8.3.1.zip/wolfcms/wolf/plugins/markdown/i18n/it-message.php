<?php

/**
 * Wolf CMS markdown plugin language file
 *
 * @package Translations
 */

return array(
    'Allows you to use the Markdown text filter (with MarkdownExtra and Smartypants).' => 'Consente di utilizzare il filtro testo Markdown (con MarkdownExtra e Smartypants).',
    'Markdown filter' => 'Filtro Markdown',
    'Markdown' => 'Markdown'
);