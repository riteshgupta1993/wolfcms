<?php

/**
 * Wolf CMS markdown plugin language file
 *
 * @package Translations
 */

return array(
    'Allows you to use the Markdown text filter (with MarkdownExtra and Smartypants).' => 'Stelt u in staat om de Markdown tekstfilter (met MarkdownExtra en Smartypants) te gebruiken.',
    'Markdown filter' => 'Markdown filter',
    'Markdown' => 'Markdown'
);