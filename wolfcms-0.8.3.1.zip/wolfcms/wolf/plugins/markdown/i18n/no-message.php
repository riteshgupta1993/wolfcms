<?php

/**
 * Wolf CMS markdown plugin language file
 *
 * @package Translations
 */

return array(
    'Allows you to use the Markdown text filter (with MarkdownExtra and Smartypants).' => 'Muliggjør bruk av Markdown tekst-filteret (med MarkdownExtra og Smartypants).',
    'Markdown filter' => 'Markdown-filter',
    'Markdown' => 'Markdown'
);