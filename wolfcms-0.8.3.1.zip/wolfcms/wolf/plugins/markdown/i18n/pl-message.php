<?php

/**
 * Wolf CMS markdown plugin language file
 *
 * @package Translations
 */

return array(
    'Allows you to use the Markdown text filter (with MarkdownExtra and Smartypants).' => 'Pozwala używać filtra tekstu Markdown (z rozszerzeniami MarkdownExtra i Smartypants)',
    'Markdown filter' => 'Filtr Markdown',
    'Markdown' => 'Markdown'
);