<?php

/**
 * Wolf CMS markdown plugin language file
 *
 * @package Translations
 */

return array(
    'Allows you to use the Markdown text filter (with MarkdownExtra and Smartypants).' => 'Permite que você use o filtro de texto Markdown (com MarkdownExtra e Smartypants).',
    'Markdown filter' => 'Filtro de texto Markdown',
    'Markdown' => 'Markdown'
);