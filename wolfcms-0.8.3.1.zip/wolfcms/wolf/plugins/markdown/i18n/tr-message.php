<?php

/**
 * Wolf CMS markdown plugin language file
 *
 * @package Translations
 */

return array(
    'Allows you to use the Markdown text filter (with MarkdownExtra and Smartypants).' => 'Markdown metin sentaksını kullanabilmenizi sağlar. (MarkdownExtra ve Smartypants ile)',
    'Markdown filter' => 'Markdown Filtrelemesi',
    'Markdown' => 'Markdown'
);