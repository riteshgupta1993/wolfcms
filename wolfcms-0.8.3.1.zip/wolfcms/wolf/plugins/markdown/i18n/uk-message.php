<?php

/**
 * Wolf CMS markdown plugin language file
 *
 * @package Translations
 */

return array(
    'Allows you to use the Markdown text filter (with MarkdownExtra and Smartypants).' => 'Дозволяє використовувати текстовий фільтр Markdown (з MarkdownExtra і Smartypants).',
    'Markdown filter' => 'Фільтр Markdown',
    'Markdown' => 'Markdown'
);