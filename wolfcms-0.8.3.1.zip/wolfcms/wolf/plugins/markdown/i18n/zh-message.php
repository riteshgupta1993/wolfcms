<?php

/**
 * Wolf CMS markdown plugin language file
 *
 * @package Translations
 */

return array(
    'Allows you to use the Markdown text filter (with MarkdownExtra and Smartypants).' => '允许您使用 Markdown 文本过滤器（与 MarkdownExtra 和 Smartypants）。',
    'Markdown filter' => 'Markdown 过滤器',
    'Markdown' => 'Markdown'
);