<?php

/**
 * Wolf CMS markdown plugin language file
 *
 * @package Translations
 */

return array(
    'Allows you to use the Markdown text filter (with MarkdownExtra and Smartypants).' => '允許您使用文字過濾器',
    'Markdown filter' => 'Markdown 文字過濾器',
    'Markdown' => 'Markdown'
);