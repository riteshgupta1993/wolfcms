<?php

/**
 * Wolf CMS page_not_found plugin language file
 *
 * @package Translations
 */

return array(
    'Page not found' => 'Stránka nebyla nalezena',
    'Provides Page not found page types.' => 'Poskytne typy stránek Stránka nebyla nalezena.'
);