<?php

/**
 * Wolf CMS page_not_found plugin language file
 *
 * @package Translations
 */

return array(
    'Page not found' => 'Seite nicht gefunden',
    'Provides Page not found page types.' => 'Stellt die "Seite nicht gefunden" seitentypen zur verfügung.'
);