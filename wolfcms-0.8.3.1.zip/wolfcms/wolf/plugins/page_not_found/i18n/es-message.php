<?php

/**
 * Wolf CMS page_not_found plugin language file
 *
 * @package Translations
 */

return array(
    'Page not found' => 'Página no encontrada',
    'Provides Page not found page types.' => 'Proporciona tipos de página para "Página no encontrada".'
);