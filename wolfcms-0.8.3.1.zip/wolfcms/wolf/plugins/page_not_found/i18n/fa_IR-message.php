<?php

/**
 * Wolf CMS page_not_found plugin language file
 *
 * @package Translations
 */

return array(
    'Page not found' => 'صفحه مورد نظر شما یافت نمیشود',
    'Provides Page not found page types.' => 'صفحه ارجاع شده یک صفحه ناپیدا شدنیست.'
);