<?php

/**
 * Wolf CMS page_not_found plugin language file
 *
 * @package Translations
 */

return array(
    'Page not found' => 'Sivua ei löytynyt',
    'Provides Page not found page types.' => 'Mahdollistaa "Sivua ei löytynyt" -sivutyypin käyttämisen.'
);