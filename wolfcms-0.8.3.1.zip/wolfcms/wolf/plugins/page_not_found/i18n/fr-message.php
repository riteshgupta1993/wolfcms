<?php

/**
 * Wolf CMS page_not_found plugin language file
 *
 * @package Translations
 */

return array(
    'Page not found' => 'Page non trouvée',
    'Provides Page not found page types.' => 'Définit la norme "Page non trouvée" disponibles.'
);