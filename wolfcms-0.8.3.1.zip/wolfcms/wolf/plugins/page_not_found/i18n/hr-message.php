<?php

/**
 * Wolf CMS page_not_found plugin language file
 *
 * @package Translations
 */

return array(
    'Page not found' => 'Stranica nije pronađena',
    'Provides Page not found page types.' => 'Pruža tip stranice "Stranica nije pronađena".'
);