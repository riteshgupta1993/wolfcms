<?php

/**
 * Wolf CMS page_not_found plugin language file
 *
 * @package Translations
 */

return array(
    'Page not found' => 'A lap nem megjeleníthető',
    'Provides Page not found page types.' => 'Add meg a "404 page not found" oldal tipusokat.'
);