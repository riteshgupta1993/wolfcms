<?php

/**
 * Wolf CMS page_not_found plugin language file
 *
 * @package Translations
 */

return array(
    'Page not found' => 'Pagina non trovata',
    'Provides Page not found page types.' => 'Fornisce il tipo di pagina "Pagina non trovata".'
);