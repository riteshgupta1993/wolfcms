<?php

/**
 * Wolf CMS page_not_found plugin language file
 *
 * @package Translations
 */

return array(
    'Page not found' => 'Pagina niet gevonden',
    'Provides Page not found page types.' => 'Biedt een pagina niet gevonden paginatype.'
);