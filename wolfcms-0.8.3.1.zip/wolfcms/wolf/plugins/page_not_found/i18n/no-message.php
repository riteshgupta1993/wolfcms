<?php

/**
 * Wolf CMS page_not_found plugin language file
 *
 * @package Translations
 */

return array(
    'Page not found' => 'Siden ble ikke funnet',
    'Provides Page not found page types.' => 'Muliggjør Siden ble ikke funnet-sidetype.'
);