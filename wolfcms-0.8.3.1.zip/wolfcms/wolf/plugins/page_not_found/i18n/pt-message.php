<?php

/**
 * Wolf CMS page_not_found plugin language file
 *
 * @package Translations
 */

return array(
    'Page not found' => 'P&aacute;gina n&atilde;o encontrada',
    'Provides Page not found page types.' => 'Fornece p&aacute;ginas do tipo "P&aacute;gina n&atilde;o encontrada".'
);