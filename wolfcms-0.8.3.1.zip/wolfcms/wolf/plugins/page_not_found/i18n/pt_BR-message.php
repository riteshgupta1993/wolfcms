<?php

/**
 * Wolf CMS page_not_found plugin language file
 *
 * @package Translations
 */

return array(
    'Page not found' => 'Página não encontrada!',
    'Provides Page not found page types.' => 'Fornece a mensagem "Página não encontrada".'
);