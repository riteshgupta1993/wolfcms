<?php

/**
 * Wolf CMS page_not_found plugin language file
 *
 * @package Translations
 */

return array(
    'Page not found' => 'Pagina nu a fost găsită',
    'Provides Page not found page types.' => 'Face disponibile tipuri de pagină pentru conţinut care nu a fost găsit.'
);