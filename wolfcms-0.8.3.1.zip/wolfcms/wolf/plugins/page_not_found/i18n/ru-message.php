<?php

/**
 * Wolf CMS page_not_found plugin language file
 *
 * @package Translations
 */

return array(
    'Page not found' => 'Страница не найдена',
    'Provides Page not found page types.' => 'Обеспечивает тип страницы — «Страница не найдена»'
);