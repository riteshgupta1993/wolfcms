<?php

/**
 * Wolf CMS page_not_found plugin language file
 *
 * @package Translations
 */

return array(
    'Page not found' => 'Sida ej hittad',
    'Provides Page not found page types.' => 'Erbjuder Sida ej hittad former.'
);