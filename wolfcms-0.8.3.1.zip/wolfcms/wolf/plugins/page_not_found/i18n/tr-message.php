<?php

/**
 * Wolf CMS page_not_found plugin language file
 *
 * @package Translations
 */

return array(
    'Page not found' => 'Sayfa bulunamadı',
    'Provides Page not found page types.' => 'Çeşitli \'Sayfa bulunamadı\' şablonları sağlar.'
);