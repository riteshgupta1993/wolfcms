<?php

/**
 * Wolf CMS page_not_found plugin language file
 *
 * @package Translations
 */

return array(
    'Page not found' => 'Сторінку не знайдено',
    'Provides Page not found page types.' => 'Забезпечує різновиди сторінок з повідомленням "Сторінку не знайдено".'
);