<?php

/**
 * Wolf CMS page_not_found plugin language file
 *
 * @package Translations
 */

return array(
    'Page not found' => '找不到网页',
    'Provides Page not found page types.' => '提供页面没有找到页面类型'
);