<?php

/**
 * Wolf CMS page_not_found plugin language file
 *
 * @package Translations
 */

return array(
    'Page not found' => '查無此頁面',
    'Provides Page not found page types.' => '提供的頁面沒有找到此相符合的頁面類型'
);