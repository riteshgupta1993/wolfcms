<?php

/**
 * Wolf CMS skeleton plugin language file
 *
 * @package Translations
 */

return array(
    'A sidebar' => 'Sidebar',
    'Display settings page here!' => 'Stranica za postavke je ovdje!',
    'Display your documentation here!' => 'Stranica za dokumentaciju je ovdje!',
    'Documentation' => 'Dokumentacija',
    'Provides a basic plugin implementation. (try enabling it!)' => 'Pruža osnovu za izradu dodatka. (pokušajte ga omogućiti!)',
    'Put something here, or leave out the sidebar entirely.' => 'Stavite nešto ovdje, ili izostaviti sidebar cijelosti.',
    'Settings' => 'Postavke',
    'Skeleton' => 'Skeleton',
    'You have modified this page.  If you navigate away from this page without first saving your data, the changes will be lost.' => 'Izmjenili ste ovu stranicu. Ako napustite ovu stranicu bez da prvo spremite svoje podatke, promjene će biti izgubljene.'
);