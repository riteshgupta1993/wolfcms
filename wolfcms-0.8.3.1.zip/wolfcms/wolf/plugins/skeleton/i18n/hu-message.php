<?php

/**
 * Wolf CMS skeleton plugin language file
 *
 * @package Translations
 */

return array(
    'A sidebar' => 'Oldalsáv',
    'Display settings page here!' => 'Beállítások megjelenítése itt!',
    'Display your documentation here!' => 'Dokumentáció megjelenítése itt!',
    'Documentation' => 'Dokumentáció',
    'Provides a basic plugin implementation. (try enabling it!)' => 'Egyszerű kiegészítő minta, fejlesztéshez. (próbáld ki)',
    'Put something here, or leave out the sidebar entirely.' => 'Valamit tehetsz ide is, de üres is maradhat az oldalsáv.',
    'Settings' => 'Beállítások',
    'Skeleton' => 'Minta',
    'You have modified this page.  If you navigate away from this page without first saving your data, the changes will be lost.' => 'Ha elnavigálsz az oldalról mentés nélkül, akkor a módosítások elvesznek.'
);