<?php

/**
 * Wolf CMS skeleton plugin language file
 *
 * @package Translations
 */

return array(
    'A sidebar' => 'Una barra laterale',
    'Display settings page here!' => 'Mostra qui la pagina delle impostazioni!',
    'Display your documentation here!' => 'Mostra qui la tua documentazione!',
    'Documentation' => 'Documentazione',
    'Provides a basic plugin implementation. (try enabling it!)' => 'Fornisce un\'implementazione di base per un plugin. (prova ad abilitarlo!)',
    'Put something here, or leave out the sidebar entirely.' => 'Metti qualcosa qui, o lascia la barra laterale vuota.',
    'Settings' => 'Impostazioni',
    'Skeleton' => 'Skeleton',
    'You have modified this page.  If you navigate away from this page without first saving your data, the changes will be lost.' => 'Hai modificato questa pagina.  Se esci da questa pagina senza prima salvare i dati, le modifiche andranno perse.'
);