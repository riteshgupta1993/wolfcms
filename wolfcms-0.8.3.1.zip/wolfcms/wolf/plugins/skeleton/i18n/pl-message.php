<?php

/**
 * Wolf CMS skeleton plugin language file
 *
 * @package Translations
 */

return array(
    'A sidebar' => 'Pasek boczny',
    'Display settings page here!' => 'Tutaj wyświetl stronę ustawień!',
    'Display your documentation here!' => 'Wyświetl tutaj dokumentację!',
    'Documentation' => 'Dokumentacja',
    'Provides a basic plugin implementation. (try enabling it!)' => 'Udostępnia przykładową implementację wtyczki (spróbuj ją włączyć!)',
    'Put something here, or leave out the sidebar entirely.' => 'Umieść coś tutaj lub pomiń całkowicie pasek boczny.',
    'Settings' => 'Ustawienia',
    'Skeleton' => 'Szkielet',
    'You have modified this page.  If you navigate away from this page without first saving your data, the changes will be lost.' => 'Wprowadziłeś zmiany na tej stronie. Jeśli przejdziesz do innej strony bez zapisywania zmiany zostaną utracone.'
);