<?php

/**
 * Wolf CMS skeleton plugin language file
 *
 * @package Translations
 */

return array(
    'A sidebar' => 'Боковая панель',
    'Display settings page here!' => 'Здесь отображаются настройки страницы',
    'Display your documentation here!' => 'Здесь отображается ваша документация!',
    'Documentation' => 'Документация',
    'Provides a basic plugin implementation. (try enabling it!)' => 'Предоставляет простейший макет плагина (включите и попробуйте)',
    'Put something here, or leave out the sidebar entirely.' => 'Напишите что-нибудь здесь или оставьте пустым',
    'Settings' => 'Настройки',
    'Skeleton' => 'Скелет',
    'You have modified this page.  If you navigate away from this page without first saving your data, the changes will be lost.' => 'Вы изменили страницу. если вы уйдете отсюда без сохранения, изменения будут потеряны.'
);