<?php

/**
 * Wolf CMS skeleton plugin language file
 *
 * @package Translations
 */

return array(
    'A sidebar' => 'Kenar Çubuğu',
    'Display settings page here!' => 'Ayarlar sayfasını burada görüntüle!',
    'Display your documentation here!' => 'Dokümantasyonu burada görüntüle!',
    'Documentation' => 'Dokümantasyon',
    'Provides a basic plugin implementation. (try enabling it!)' => 'Temel bir eklenti uygulaması sağlar. (etkinleştirmeyi deneyin!)',
    'Put something here, or leave out the sidebar entirely.' => 'Buraya birşeyler yazın veya kenar çubuğunu tamamen devre dışı bırakın.',
    'Settings' => 'Ayarlar',
    'Skeleton' => 'İskelet',
    'You have modified this page.  If you navigate away from this page without first saving your data, the changes will be lost.' => 'Bu sayfayı düzenlediniz. Eğer değişikliklerinizi kaydetmeden bu sayfadan ayrılırsanız değişiklikleriniz silinecektir.'
);