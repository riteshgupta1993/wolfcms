<?php

/**
 * Wolf CMS skeleton plugin language file
 *
 * @package Translations
 */

return array(
    'A sidebar' => 'A sidebar',
    'Display settings page here!' => 'Display settings page here!',
    'Display your documentation here!' => 'Display your documentation here!',
    'Documentation' => '說明文件',
    'Provides a basic plugin implementation. (try enabling it!)' => 'Provides a basic plugin implementation. (try enabling it!)',
    'Put something here, or leave out the sidebar entirely.' => 'Put something here, or leave out the sidebar entirely.',
    'Settings' => '網站設定',
    'Skeleton' => 'Skeleton',
    'You have modified this page.  If you navigate away from this page without first saving your data, the changes will be lost.' => 'You have modified this page.  If you navigate away from this page without first saving your data, the changes will be lost.'
);