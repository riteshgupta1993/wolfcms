<?php

/**
 * Wolf CMS textile plugin language file
 *
 * @package Translations
 */

return array(
    'Allows you to use the Textile text filter.' => 'Позволява ви да използвате текстовия филтър Textile.',
    'Textile filter' => 'Филтър Textile',
    'Textile' => 'Textile'
);