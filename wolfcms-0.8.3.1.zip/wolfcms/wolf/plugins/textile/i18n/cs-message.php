<?php

/**
 * Wolf CMS textile plugin language file
 *
 * @package Translations
 */

return array(
    'Allows you to use the Textile text filter.' => 'Umožňuje Vám využívat textový filtr Textile.',
    'Textile filter' => 'Textile filtr',
    'Textile' => 'Textile'
);