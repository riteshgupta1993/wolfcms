<?php

/**
 * Wolf CMS textile plugin language file
 *
 * @package Translations
 */

return array(
    'Allows you to use the Textile text filter.' => 'Allows you to use the Textile text filter.',
    'Textile filter' => 'Textile filter',
    'Textile' => 'Textile'
);