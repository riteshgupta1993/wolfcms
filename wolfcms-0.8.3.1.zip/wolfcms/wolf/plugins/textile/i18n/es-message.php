<?php

/**
 * Wolf CMS textile plugin language file
 *
 * @package Translations
 */

return array(
    'Allows you to use the Textile text filter.' => 'Le permite utilizar el filtro de texto Textile',
    'Textile filter' => 'Filtro Textile',
    'Textile' => 'Textile'
);