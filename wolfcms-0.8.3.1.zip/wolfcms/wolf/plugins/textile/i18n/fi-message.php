<?php

/**
 * Wolf CMS textile plugin language file
 *
 * @package Translations
 */

return array(
    'Allows you to use the Textile text filter.' => 'Mahdollistaa Textile-suotimen käyttämisen.',
    'Textile filter' => 'Textile-suodin',
    'Textile' => 'Textile'
);