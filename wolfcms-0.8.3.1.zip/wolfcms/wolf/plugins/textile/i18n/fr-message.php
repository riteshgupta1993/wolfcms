<?php

/**
 * Wolf CMS textile plugin language file
 *
 * @package Translations
 */

return array(
    'Allows you to use the Textile text filter.' => 'Vous permet d\'utiliser le filtre de texte Textile.',
    'Textile filter' => 'Filtre Textile',
    'Textile' => 'Textile'
);