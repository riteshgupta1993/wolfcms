<?php

/**
 * Wolf CMS textile plugin language file
 *
 * @package Translations
 */

return array(
    'Allows you to use the Textile text filter.' => 'Omogućava vam da koristite Textile kao tekstulani filter.',
    'Textile filter' => 'Textile filter',
    'Textile' => 'Textile'
);