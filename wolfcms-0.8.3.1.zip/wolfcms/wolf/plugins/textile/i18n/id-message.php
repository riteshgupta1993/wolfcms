<?php

/**
 * Wolf CMS textile plugin language file
 *
 * @package Translations
 */

return array(
    'Allows you to use the Textile text filter.' => 'Memungkinkan anda untuk menggunakan filter teks Textile.',
    'Textile filter' => 'Filter Textile ',
    'Textile' => 'Textile'
);