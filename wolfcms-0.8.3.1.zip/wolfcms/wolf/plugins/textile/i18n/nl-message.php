<?php

/**
 * Wolf CMS textile plugin language file
 *
 * @package Translations
 */

return array(
    'Allows you to use the Textile text filter.' => 'Stelt u in staat om de Textile tekstfilter te gebruiken.',
    'Textile filter' => 'Textile filter',
    'Textile' => 'Textile'
);