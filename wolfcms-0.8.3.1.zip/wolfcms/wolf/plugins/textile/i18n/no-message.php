<?php

/**
 * Wolf CMS textile plugin language file
 *
 * @package Translations
 */

return array(
    'Allows you to use the Textile text filter.' => 'Muliggjør bruk av Textile tekst-filteret.',
    'Textile filter' => 'Tekst-filter',
    'Textile' => 'Tekst'
);