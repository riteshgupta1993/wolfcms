<?php

/**
 * Wolf CMS textile plugin language file
 *
 * @package Translations
 */

return array(
    'Allows you to use the Textile text filter.' => 'Pozwala używać fitra tekstu Textile.',
    'Textile filter' => 'Filtr Textile',
    'Textile' => 'Textile'
);