<?php

/**
 * Wolf CMS textile plugin language file
 *
 * @package Translations
 */

return array(
    'Allows you to use the Textile text filter.' => 'Permite voc&ecirc; usar o filtro de textos Textile.',
    'Textile filter' => 'Filtro Textile',
    'Textile' => 'Textile'
);