<?php

/**
 * Wolf CMS textile plugin language file
 *
 * @package Translations
 */

return array(
    'Allows you to use the Textile text filter.' => 'Permite que você utilize o filtro de texto Textile.',
    'Textile filter' => 'Filtro de texto Textile',
    'Textile' => 'Textile'
);