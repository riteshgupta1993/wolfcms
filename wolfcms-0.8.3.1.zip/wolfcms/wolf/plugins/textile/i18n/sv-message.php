<?php

/**
 * Wolf CMS textile plugin language file
 *
 * @package Translations
 */

return array(
    'Allows you to use the Textile text filter.' => 'Tillåter dig att använda Textil-textfiltret.',
    'Textile filter' => 'Textil-filter',
    'Textile' => 'Textil'
);