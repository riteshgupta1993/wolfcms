<?php

/**
 * Wolf CMS textile plugin language file
 *
 * @package Translations
 */

return array(
    'Allows you to use the Textile text filter.' => '允许您使用 Textile 的文本过滤器。',
    'Textile filter' => 'Textile 过滤器',
    'Textile' => 'Textile'
);