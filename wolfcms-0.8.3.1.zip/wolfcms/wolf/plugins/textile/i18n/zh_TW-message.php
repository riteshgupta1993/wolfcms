<?php

/**
 * Wolf CMS textile plugin language file
 *
 * @package Translations
 */

return array(
    'Allows you to use the Textile text filter.' => '允許使用文字標題過濾功能',
    'Textile filter' => '文字標題過濾器',
    'Textile' => '文字標題'
);